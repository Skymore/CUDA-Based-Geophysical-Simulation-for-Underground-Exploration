nvcc -arch sm_61  kernel.cu -o kernel
./kernel