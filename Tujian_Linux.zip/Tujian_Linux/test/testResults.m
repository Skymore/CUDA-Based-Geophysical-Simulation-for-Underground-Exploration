results = zeros(185,1000);
results = load('C:\Users\sky\Desktop\Tujian_mac\output\E_obs.txt','-ascii');